﻿Add-MailboxPermission -Identity "alber.startup@vertivco.com" `
-User Keane.Bennett@vertivco.com -AccessRights Fullaccess -Confirm:$false